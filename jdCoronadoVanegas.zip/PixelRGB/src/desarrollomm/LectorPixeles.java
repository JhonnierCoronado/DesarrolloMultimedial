/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desarrollomm;

/**
 *
 * @author nnohj
 */
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;

import static java.lang.Math.*;

import javax.imageio.ImageIO;

public class LectorPixeles {

    public static final int RGB = 10;
    public static final int ARGB = 11;

    private int mModo;
    private BufferedImage mImagen;
    private int ancho = 0;
    private int alto = 0;
    


    
    private double cuanti[][] = { {16,11,10,16,24,40,51,61},
                                  {12,12,14,19,26,58,60,55},
                                  {14,13,16,24,40,57,69,56},
                                  {14,17,22,29,51,87,80,62},
                                  {18,22,37,56,68,109,103,77},
                                  {24,35,55,64,81,104,113,92},
                                  {49,64,78,87,103,121,120,101},
                                  {72,92,95,98,112,100,103,99}
                                };
    
    public LectorPixeles(String file, int modo) {
            try {
                    mImagen = ImageIO.read(new File(file));
                    mModo = modo;
            } catch (IOException e) {
                    System.err.println(e.getMessage());
            }
    }
    public void iniciarProceso() {
            ancho = mImagen.getWidth();
            alto = mImagen.getHeight();
            RGBtoY();
    }
    
    
    private void RGBtoY(){
        double [][]YCbCr = new double[alto][ancho];
        double Y = 0;
        for (int i = 0; i < alto; i++) {
            for (int j = 0; j < ancho; j++) {
                int pixel = mImagen.getRGB(j, i);
                int rojo = (pixel >> 16) & 0xff;
                int verde = (pixel >> 8) & 0xff;
                int azul = (pixel) & 0xff;
                Y = 0 + (0.299 * rojo) + (0.587 * verde) + (0.114 * azul);
                YCbCr[i][j] = Math.round(Y)-128;
            }
        }
        System.out.println("Y");
        for (int u = 0; u < alto; u++) {
            for (int v = 0; v < ancho; v++) {
                System.out.print(YCbCr[u][v] + "\t");
            }
            System.out.println("");
        }
        DCT(YCbCr);
    }
    
    private void DCT(double YCbCr[][]){
        
        double [][]DCT = new double[alto][ancho];
        double au = 0;
        double av = 0;
        double result = 0;
        
        for (int u = 0; u < alto; u++) {
            for (int v = 0; v < ancho; v++) {
                au = alpha(au);
                av = alpha(av);
                for (int x = 0; x < ancho; x++) {
                    for (int y = 0; y < alto; y++) {
                        result = YCbCr[x][y]*Math.cos((Math.PI*(2*x+1)*u)/2*alto)*Math.cos((Math.PI*(2*y+1)*v)/2*alto);
                    }                    
                }
                DCT[u][v] = Math.round(result);
            } 
        }
        System.out.println("DCT");
        for (int u = 0; u < alto; u++) {
            for (int v = 0; v < ancho; v++) {
                System.out.print(DCT[u][v] + "\t");
            }
            System.out.println("");
        }
        dividir(DCT);
    }
    
    private void dividir(double DCT[][]){
        double [][]Div = new double[alto][ancho];
        for (int i = 0; i < alto; i++) {
            for (int j = 0; j < ancho; j++) {
                Div[i][j] = Math.round(DCT[i][j] / cuanti[i][j]); 
            }
        }
        System.out.println("Division");
        for (int u = 0; u < alto; u++) {
            for (int v = 0; v < ancho; v++) {
                System.out.print(Div[u][v] + "\t");
            }
            System.out.println("");
        }
       //Huffman(Div);
    }
    
    private void Huffman(double Div[][]){
        int fila = 0;
        int columna = 0;
        
        boolean x = false;
        
        for (int i = 0; i < ancho; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print(Div[i][j] + "\t"); 
                if (j + 1 == i)
                    break;
                if (x){
                    fila ++;
                    columna --;
                } else{
                    fila --;
                    columna ++;
                }
            }
            if (i == ancho)
                break;
            if (x){
                fila ++;
                x = false;
            }
            else{
                columna ++;
                x = true;
            }
        }
        if (fila == 0){
            if (columna == ancho - 1){
                fila ++;
            }
            else {
                columna ++;
            }
            x = true;
        }
        for (int i, diagonal = ancho; diagonal > 0; diagonal --){
            if (diagonal > ancho)
                i = ancho;
            else
                i = diagonal;
            
            for (int j = 0; j < i; j++){
                System.out.print(Div[i][j] + "\t"); 
                if (j+1 == i)
                    break;
                if(x){
                    fila ++;
                    columna --;
                }
                else {
                    columna ++;
                    fila --;
                }
            }
            if (fila == 0 || columna == ancho - 1){
                if (columna == ancho - 1)
                    fila ++;
                else
                    columna ++;
                x = true;
            }
            else if (columna == 0 || fila == ancho - 1) { 
                if (fila == ancho - 1) 
                    columna ++; 
                else
                    fila ++; 
  
                x = false; 
            } 
        }
    }
    private double alpha(double x){
        if (x == 0)
            return 1/Math.sqrt(2);
        else
            return 1;
    }
    
    private void imprimirARGB(int pixel) {
            int alpha = 0;
            int rojo = (pixel >> 16) & 0xff;
            int verde = (pixel >> 8) & 0xff;
            int azul = (pixel) & 0xff;
            StringBuilder sbuilder = new StringBuilder();

            if (mModo == ARGB) {
                    alpha = (pixel >> 24) & 0xff;

                    sbuilder.append("alpha: ");
                    sbuilder.append(alpha);
                    sbuilder.append(", ");
            }

            sbuilder.append("rojo: ");
            sbuilder.append(rojo);
            sbuilder.append(", ");

            sbuilder.append("verde: ");
            sbuilder.append(verde);
            sbuilder.append(", ");

            sbuilder.append("azul: ");
            sbuilder.append(azul);
            sbuilder.append(".");

            System.out.println(sbuilder.toString());

    }

}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desarrollomm;

/**
 *
 * @author nnohj
 */
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;

import static java.lang.Math.*;

import javax.imageio.ImageIO;

public class LectorPixeles {

    public static final int RGB = 10;
    public static final int ARGB = 11;

    private int mModo;
    private int mModo2;
    private BufferedImage mImagen;
    private BufferedImage mImagen2;

    public LectorPixeles(String file, String file2, int modo, int modo2) {
        try {
            mImagen = ImageIO.read(new File(file));
            mModo = modo;
            mImagen2 = ImageIO.read(new File(file2));
            mModo2 = modo2;
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public void iniciarProceso() {
        int ancho = mImagen.getWidth();
        int alto = mImagen.getHeight();
        int ancho2 = mImagen2.getWidth();
        int alto2 = mImagen2.getHeight();
        
        double difference[] = {0,0};
        
        System.out.println("ancho, alto: " + ancho + ", " + alto);
        if (ancho2 == ancho && alto2 == alto) {
            calcularECM(mImagen, mImagen2, ancho, alto, difference);
            mImagen.flush();
        }
        System.out.println("El ECM es: " + difference[0]);
        System.out.println("El PSNR es: " + difference[1]);
        
    }
    public static double logbase10(double x) {
        return Math.log(x) / Math.log(10);
    }
    private void calcularECM(BufferedImage i1, BufferedImage i2, int ancho, int alto, double difference[]){
        Raster r1 = i1.getRaster();
        Raster r2 = i2.getRaster();
        double ecm = 0;
        double psnr = 0;
        for (int j= 0; j < alto; j++){
            for (int i = 0; i < ancho; i++) {
                ecm += pow(r1.getSample(i, j, 0) - r2.getSample(i, j, 0), 2);
            }
        }
        ecm = ecm/(double)(alto*ancho);
        difference[0] =  ecm;
        psnr = 10.0 * logbase10(pow(255,2) / ecm);
        difference[1] = psnr;
    }
    

    private void imprimirARGB(int pixel) {
        int alpha = 0;
        int rojo = (pixel >> 16) & 0xff;
        int verde = (pixel >> 8) & 0xff;
        int azul = (pixel) & 0xff;
        StringBuilder sbuilder = new StringBuilder();

        if (mModo == ARGB) {
            alpha = (pixel >> 24) & 0xff;
        } 

        sbuilder.append("rojo: ");
        sbuilder.append(rojo);
        sbuilder.append(", ");

        sbuilder.append("verde: ");
        sbuilder.append(verde);
        sbuilder.append(", ");

        sbuilder.append("azul: ");
        sbuilder.append(azul);
        sbuilder.append(".");

        System.out.println(sbuilder.toString());

    }

}
